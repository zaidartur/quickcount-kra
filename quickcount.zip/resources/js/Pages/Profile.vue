<script setup>
    import AppLayout from "@/Layouts/AppLayout.vue";
    import Setting  from "@/Pages/Settings/View.vue";
</script>

<template>
    <app-layout>
        <Setting />
    </app-layout>
</template>
    
<style scoped lang="scss">
    
</style>
    